import argparse

from utils import manual_control, run_random_episodes

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Run a simulation in the Simple2DNavigationEnv."
    )
    parser.add_argument(
        "--mode",
        choices=["random", "manual"],
        default="manual",
        help="The mode to run the simulation in: 'random' for random actions, 'manual' for user control.",
    )
    parser.add_argument(
        "-e",
        "--episodes",
        type=int,
        default=5,
        help="Number of episodes to run in 'random' mode. (Default: 5)",
    )
    parser.add_argument(
        "-s",
        "--size",
        type=int,
        default=20,
        help="The height and width of the grid for the environment. (Default: 10)",
    )
    parser.add_argument(
        "-c",
        "--complexity",
        type=float,
        default=0.5,
        help="Maze complexity from 0.0 (empty room) to 1.0 (perfect maze). (Default: 0.5)",
    )
    parser.add_argument(
        "--obs-modality",
        choices=["image", "text"],
        default="text",
        help="Observation modality: 'image' for RGB images, 'text' for text descriptions. (Default: image)",
    )
    parser.add_argument(
        "--observability",
        choices=["full", "partial"],
        default="partial",
        help="Observability level: 'full' for complete environment visibility, 'partial' for limited visibility. (Default: full)",
    )
    parser.add_argument(
        "--save-images",
        action="store_true",
        help="Save observation images during execution (only works with image modality)",
    )
    parser.add_argument(
        "--config-path",
        type=str,
        default="text_configs/example_config.json",
        help="Path to a JSON configuration file for text observations",
    )
    args = parser.parse_args()

    if args.mode == "random":
        print(
            f"Running in random mode for {args.episodes} episodes with a grid size of {args.size}x{args.size}."
            f" Complexity: {args.complexity}, Observation modality: {args.obs_modality}, Observability: {args.observability}"
        )
        run_random_episodes(
            episodes=args.episodes,
            size=args.size,
            complexity=args.complexity,
            obs_modality=args.obs_modality,
            observability=args.observability,
            save_images=args.save_images,
            config_path=args.config_path,
        )
    elif args.mode == "manual":
        print(
            f"Running in manual mode with a grid size of {args.size}x{args.size}."
            f" Complexity: {args.complexity}, Observation modality: {args.obs_modality}, Observability: {args.observability}"
        )
        manual_control(
            size=args.size,
            complexity=args.complexity,
            obs_modality=args.obs_modality,
            observability=args.observability,
            save_images=args.save_images,
            config_path=args.config_path,
        )
